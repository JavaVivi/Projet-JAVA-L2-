
package projet.data;

import java.io.File;

/**
 * @author vcaze
 * @version 1.0
 *
 */
public interface Sauvegarde {
	/**
	 * @param f
	 * @throws WrongExtensionException
	 */
	public static void lecture_et_sauvegarde_fichier(File f) throws WrongExtensionException {
	}
	/**
	 * @param f
	 */
	public static void serialisation(File f) {
	}
	/**
	 * @param f
	 */
	public static void serialisation_lecture(File f) {
	}
	/**
	 * @param f
	 */
	public static void fragment_HTML(File f) {
	}
}
